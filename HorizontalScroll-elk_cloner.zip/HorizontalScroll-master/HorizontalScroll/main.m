//
//  main.m
//  HorizontalScroll
//
//  Created by Tejas Kutal on 05/06/17.
//  Copyright © 2017 XYZasdabcd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
