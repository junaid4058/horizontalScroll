//
//  ViewController.h
//  HorizontalScroll
//
//  Created by Tejas Kutal on 05/06/17.
//  Copyright © 2017 XYZasdabcd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

